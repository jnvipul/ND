package com.example.android.sunshine.app;

/**
 * Created by VJ on 27/11/16.
 */


import android.content.res.Resources;
import android.support.annotation.NonNull;

import java.util.Calendar;

public class Utility {

    /**
     * Helper method to provide the icon resource id according to the weather condition id returned
     * by the OpenWeatherMap call.
     *
     * @param weatherId from OpenWeatherMap API response
     * @return resource id for the corresponding icon. -1 if no relation is found.
     */
    public static int getIconResourceForWeatherCondition(int weatherId) {
        // Based on weather code data found at:
        // http://bugs.openweathermap.org/projects/api/wiki/Weather_Condition_Codes
        if (weatherId >= 200 && weatherId <= 232) {
            return com.example.android.sunshine.app.R.drawable.ic_storm;
        }
        else if (weatherId >= 300 && weatherId <= 321) {
            return com.example.android.sunshine.app.R.drawable.ic_light_rain;
        }
        else if (weatherId >= 500 && weatherId <= 504) {
            return com.example.android.sunshine.app.R.drawable.ic_rain;
        }
        else if (weatherId == 511) {
            return com.example.android.sunshine.app.R.drawable.ic_snow;
        }
        else if (weatherId >= 520 && weatherId <= 531) {
            return com.example.android.sunshine.app.R.drawable.ic_rain;
        }
        else if (weatherId >= 600 && weatherId <= 622) {
            return com.example.android.sunshine.app.R.drawable.ic_snow;
        }
        else if (weatherId >= 701 && weatherId <= 761) {
            return com.example.android.sunshine.app.R.drawable.ic_fog;
        }
        else if (weatherId == 761 || weatherId == 781) {
            return com.example.android.sunshine.app.R.drawable.ic_storm;
        }
        else if (weatherId == 800) {
            return com.example.android.sunshine.app.R.drawable.ic_clear;
        }
        else if (weatherId == 801) {
            return com.example.android.sunshine.app.R.drawable.ic_light_clouds;
        }
        else if (weatherId >= 802 && weatherId <= 804) {
            return com.example.android.sunshine.app.R.drawable.ic_cloudy;
        }
        return -1;
    }

    @NonNull
    public static String getMonthOfYearString(Resources resources, int monthOfYear) {
        int monthOfYearString;
        switch (monthOfYear) {
            case Calendar.JANUARY:
                monthOfYearString = com.example.android.sunshine.app.R.string.january;
                break;
            case Calendar.FEBRUARY:
                monthOfYearString = com.example.android.sunshine.app.R.string.february;
                break;
            case Calendar.MARCH:
                monthOfYearString = com.example.android.sunshine.app.R.string.march;
                break;
            case Calendar.APRIL:
                monthOfYearString = com.example.android.sunshine.app.R.string.april;
                break;
            case Calendar.MAY:
                monthOfYearString = com.example.android.sunshine.app.R.string.may;
                break;
            case Calendar.JUNE:
                monthOfYearString = com.example.android.sunshine.app.R.string.june;
                break;
            case Calendar.JULY:
                monthOfYearString = com.example.android.sunshine.app.R.string.july;
                break;
            case Calendar.AUGUST:
                monthOfYearString = com.example.android.sunshine.app.R.string.august;
                break;
            case Calendar.SEPTEMBER:
                monthOfYearString = com.example.android.sunshine.app.R.string.september;
                break;
            case Calendar.OCTOBER:
                monthOfYearString = com.example.android.sunshine.app.R.string.october;
                break;
            case Calendar.NOVEMBER:
                monthOfYearString = com.example.android.sunshine.app.R.string.november;
                break;
            case Calendar.DECEMBER:
                monthOfYearString = com.example.android.sunshine.app.R.string.december;
                break;
            default:
                monthOfYearString = -1;
        }

        if (monthOfYearString != -1) {
            return resources.getString(monthOfYearString);
        }

        return "";
    }

    @NonNull
    public static String getDayOfWeekString(Resources resources, int day) {
        int dayOfWeekString;
        switch (day) {
            case Calendar.SUNDAY:
                dayOfWeekString = com.example.android.sunshine.app.R.string.sunday;
                break;
            case Calendar.MONDAY:
                dayOfWeekString = com.example.android.sunshine.app.R.string.monday;
                break;
            case Calendar.TUESDAY:
                dayOfWeekString = com.example.android.sunshine.app.R.string.tuesday;
                break;
            case Calendar.WEDNESDAY:
                dayOfWeekString = com.example.android.sunshine.app.R.string.wednesday;
                break;
            case Calendar.THURSDAY:
                dayOfWeekString = com.example.android.sunshine.app.R.string.thursday;
                break;
            case Calendar.FRIDAY:
                dayOfWeekString = com.example.android.sunshine.app.R.string.friday;
                break;
            case Calendar.SATURDAY:
                dayOfWeekString = com.example.android.sunshine.app.R.string.saturday;
                break;
            default:
                dayOfWeekString = -1;
        }

        if (dayOfWeekString != -1) {
            return resources.getString(dayOfWeekString);
        }

        return "";
    }

    public static String getAmPmString(Resources resources, int am_pm) {
        return am_pm == Calendar.AM ?
                resources.getString(com.example.android.sunshine.app.R.string.am) : resources.getString(com.example
                .android.sunshine.app.R.string.pm);
    }
}
